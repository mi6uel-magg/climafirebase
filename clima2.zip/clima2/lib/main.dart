
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main () async {
 WidgetsFlutterBinding.ensureInitialized();

 await  Firebase.initializeApp(
   options: FirebaseOptions(
   apiKey: "XXX",
   appId: "XXX",
   messagingSenderId: "XXX",
   projectId: "My Projetc 65809",
 ),
 );
  runApp(
    MaterialApp(
      title: 'Weather App',
      home:Home(),
    ),
);}

class Home extends StatefulWidget {

  @override
  State<StatefulWidget> createState () {
    return _HomeState();
  }
}
class _HomeState extends State<Home>{
  var temp;
  var description;
  var currently;
  var humidity;
  var windSpeed;

  Future getWeather () async {
    var url= Uri.parse("https://api.openweathermap.org/data/2.5/weather?q=Guadalajara&units=metric&appid=4831acbdc8680526f74a9abe4ee17213");
    http.Response response = await http.get(url);
    var results = jsonDecode(response.body);
    setState(() {
      this.temp = results['main']['temp'];
      this.description = results['weather'][0]['description'];
      this.currently = results['weather'][0]['main'];
      this.humidity = results['main']['humidity'];
      this.windSpeed = results['wind']['speed'];
    });

  }
  @override
  void initState (){
    super.initState();
    this.getWeather();
    getUsers();
  }
 void getUsers() async {
    CollectionReference collectionrefernece = FirebaseFirestore.instance.collection('usuarios');
    QuerySnapshot usuarios = await collectionrefernece.get();
    if (usuarios.docs.length != 0){
  for (var doc in usuarios.docs){
    print(doc.data());
  }
  }}


  @override
  Widget build (BuildContext context){
    return Scaffold(
      body: Column(
        children:<Widget> [
          Container(
            height: MediaQuery.of(context).size.height / 3,
            width: MediaQuery.of(context).size.width,
            color: Colors.blue,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Padding (padding: EdgeInsets.only(bottom: 10.0),
                  child: Text("Temperatura en Guadaljara",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Text(temp != null ? temp.toString() + "°" : "loading",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 40.0,
                      fontWeight: FontWeight.w600
                  ),
                ),
                Padding (padding: EdgeInsets.only(top: 10.0),
                  child: Text(currently != null ? currently.toString(): "loading" ,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(child:Padding(
            padding: EdgeInsets.all(20.0),
            child: ListView(
              children: <Widget> [
                ListTile(
                  leading: FaIcon(FontAwesomeIcons.thermometerHalf),
                  title: Text("Temperatura"),
                  trailing: Text(temp != null ? temp.toString() + "°": "loading"),
                ),
                ListTile(
                  leading: FaIcon(FontAwesomeIcons.cloud),
                  title: Text("Clima"),
                  trailing: Text(description != null? description.toString():"loading"),
                ),
                ListTile(
                  leading: FaIcon(FontAwesomeIcons.sun),
                  title: Text("Humedad"),
                  trailing: Text(humidity != null? humidity.toString():"loading"),
                ),
                ListTile(
                  leading: FaIcon(FontAwesomeIcons.wind),
                  title: Text("Viento"),
                  trailing: Text(windSpeed != null ? windSpeed.toString():"loading"),
                ),
              ],
            ),
          ),
          ),
        ],
      ),
    );
  }
}