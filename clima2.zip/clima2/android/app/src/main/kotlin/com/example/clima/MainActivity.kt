package com.example.clima

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
